﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MortgageCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Double payMonthly;
                if(!Double.TryParse(pay_mnthly.Text, out payMonthly)){
                    MessageBox.Show("PayMonthly is not a valid numer!");
                    return;
                }

                double monthsToPayOff = Convert.ToDouble(pay_mnthly.Text) / 12;
                int yearsToPayOff = Convert.ToInt32(pay_yrly.Text);
                double totalPayOff = Convert.ToDouble(tot_mny.Text);
                double totalPayOffFlat = Convert.ToDouble(tot_mny.Text);
                double zinsenJahr = Convert.ToDouble(zinsProJahr.Text);

                while (yearsToPayOff != 0)
                {
                    totalPayOff = totalPayOff + (totalPayOffFlat * zinsenJahr) / 100;
                    yearsToPayOff--;
                }
                if (monthsToPayOff != 0)
                {
                    totalPayOff = totalPayOff + (totalPayOffFlat * zinsenJahr) / 100 / monthsToPayOff;
                }
                int timeToPayOff = Convert.ToInt32(pay_yrly.Text) * 12 + Convert.ToInt32(pay_mnthly.Text);

                double payOffMonthly = totalPayOff / timeToPayOff;
                pymnts_mthly.Text = payOffMonthly.ToString();

                double payOffYearly = payOffMonthly * 12;
                pymnts_yrly.Text = payOffYearly.ToString();

                double payOffWeekly = payOffYearly / 52;
                pymnts_wkly.Text = payOffWeekly.ToString();

                double payOffDaily = payOffYearly / 365;
                pymnts_dly.Text = payOffDaily.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: { ex.Message }");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double dailyPayments = 0;
            double weeklyPayments = 0;
            double monthlyPayments = 0;
            double yearlyPayments = 0;
            if (pymnts_dly.Text != "")
            {
                dailyPayments = Convert.ToDouble(pymnts_dly.Text);
            }
            if (pymnts_wkly.Text != "")
            {
                weeklyPayments = Convert.ToDouble(pymnts_wkly.Text);
            }
            if (pymnts_mthly.Text != "")
            {
                monthlyPayments = Convert.ToDouble(pymnts_mthly.Text);
            }
            if (pymnts_yrly.Text != "")
            {
                yearlyPayments = Convert.ToDouble(pymnts_yrly.Text);
            }

            double totalMonthlyPayments = (dailyPayments * 30) + (weeklyPayments * 4.34) + (monthlyPayments) + (yearlyPayments / 12);
            double totalPayOff = Convert.ToDouble(tot_mny.Text);
            double totalPayOffFlat = Convert.ToDouble(tot_mny.Text);
            double zinsenJahr = Convert.ToDouble(zinsProJahr.Text);

            double monthCounter = 0;
            int yearCounter = 0;

            while(totalPayOff > 0)
            {
                monthCounter++;
                
                totalPayOff = totalPayOff + (totalPayOffFlat / 100 * (zinsenJahr/12)) - totalMonthlyPayments;

                if (monthCounter >= 12)
                {
                    yearCounter++;
                    monthCounter = monthCounter - 12;
                }
            }

            pay_mnthly.Text = monthCounter.ToString();
            pay_yrly.Text = yearCounter.ToString();
        }
    }
}
