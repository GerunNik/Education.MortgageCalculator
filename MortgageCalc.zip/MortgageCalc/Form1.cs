﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MortgageCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Double payMonthly;
                if(!Double.TryParse(pay_mnthly.Text, out payMonthly)){
                    MessageBox.Show("PayMonthly is not a valid numer!");
                    return;
                }

                double monthsToPayOff = Convert.ToDouble(pay_mnthly.Text) / 12;
                int yearsToPayOff = Convert.ToInt32(pay_yrly.Text);
                double totalPayOff = Convert.ToDouble(tot_mny.Text);
                double totalPayOffFlat = Convert.ToDouble(tot_mny.Text);
                double zinsenJahr = Convert.ToDouble(zinsProJahr.Text);

                while (yearsToPayOff != 0)
                {
                    totalPayOff = totalPayOff + (totalPayOffFlat * zinsenJahr) / 100;
                    yearsToPayOff--;
                }
                if (monthsToPayOff != 0)
                {
                    totalPayOff = totalPayOff + (totalPayOffFlat * zinsenJahr) / 100 / monthsToPayOff;
                }
                int timeToPayOff = Convert.ToInt32(pay_yrly.Text) * 12 + Convert.ToInt32(pay_mnthly.Text);

                double payOffMonthly = totalPayOff / timeToPayOff;
                pymnts_mthly.Text = payOffMonthly.ToString();

                double payOffYearly = payOffMonthly * 12;
                pymnts_yrly.Text = payOffYearly.ToString();

                double payOffWeekly = payOffYearly / 52;
                pymnts_wkly.Text = payOffWeekly.ToString();

                double payOffDaily = payOffYearly / 365;
                pymnts_dly.Text = payOffDaily.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: { ex.Message }");
            }
        }
    }
}
