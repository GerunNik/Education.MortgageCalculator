﻿namespace MortgageCalc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tot_mny = new System.Windows.Forms.TextBox();
            this.pay_yrly = new System.Windows.Forms.TextBox();
            this.pymnts_dly = new System.Windows.Forms.TextBox();
            this.pymnts_wkly = new System.Windows.Forms.TextBox();
            this.pymnts_yrly = new System.Windows.Forms.TextBox();
            this.pymnts_mthly = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pay_mnthly = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.zinsProJahr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tot_mny
            // 
            this.tot_mny.Location = new System.Drawing.Point(240, 51);
            this.tot_mny.Name = "tot_mny";
            this.tot_mny.Size = new System.Drawing.Size(100, 20);
            this.tot_mny.TabIndex = 0;
            // 
            // pay_yrly
            // 
            this.pay_yrly.Location = new System.Drawing.Point(105, 206);
            this.pay_yrly.Name = "pay_yrly";
            this.pay_yrly.Size = new System.Drawing.Size(100, 20);
            this.pay_yrly.TabIndex = 1;
            // 
            // pymnts_dly
            // 
            this.pymnts_dly.Location = new System.Drawing.Point(374, 188);
            this.pymnts_dly.Name = "pymnts_dly";
            this.pymnts_dly.Size = new System.Drawing.Size(100, 20);
            this.pymnts_dly.TabIndex = 2;
            // 
            // pymnts_wkly
            // 
            this.pymnts_wkly.Location = new System.Drawing.Point(374, 207);
            this.pymnts_wkly.Name = "pymnts_wkly";
            this.pymnts_wkly.Size = new System.Drawing.Size(100, 20);
            this.pymnts_wkly.TabIndex = 3;
            // 
            // pymnts_yrly
            // 
            this.pymnts_yrly.Location = new System.Drawing.Point(374, 243);
            this.pymnts_yrly.Name = "pymnts_yrly";
            this.pymnts_yrly.Size = new System.Drawing.Size(100, 20);
            this.pymnts_yrly.TabIndex = 4;
            // 
            // pymnts_mthly
            // 
            this.pymnts_mthly.Location = new System.Drawing.Point(374, 226);
            this.pymnts_mthly.Name = "pymnts_mthly";
            this.pymnts_mthly.Size = new System.Drawing.Size(100, 20);
            this.pymnts_mthly.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(265, 180);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(237, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Total amount of Payments";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(102, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Meantime to pay off";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(371, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Payments";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(480, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Daily";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(480, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Weekly";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(480, 229);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Monthly";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(480, 246);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Yearly";
            // 
            // pay_mnthly
            // 
            this.pay_mnthly.Location = new System.Drawing.Point(105, 223);
            this.pay_mnthly.Name = "pay_mnthly";
            this.pay_mnthly.Size = new System.Drawing.Size(100, 20);
            this.pay_mnthly.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(211, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Years";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(211, 226);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Months";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(237, 78);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Zinsen im Jahr";
            // 
            // zinsProJahr
            // 
            this.zinsProJahr.Location = new System.Drawing.Point(240, 94);
            this.zinsProJahr.Name = "zinsProJahr";
            this.zinsProJahr.Size = new System.Drawing.Size(100, 20);
            this.zinsProJahr.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(346, 97);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "%";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(265, 241);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 20;
            this.button2.Text = "Calculate";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(287, 206);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "---->";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(287, 225);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(25, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "<----";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(735, 440);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.zinsProJahr);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.pay_mnthly);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pymnts_mthly);
            this.Controls.Add(this.pymnts_yrly);
            this.Controls.Add(this.pymnts_wkly);
            this.Controls.Add(this.pymnts_dly);
            this.Controls.Add(this.pay_yrly);
            this.Controls.Add(this.tot_mny);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tot_mny;
        private System.Windows.Forms.TextBox pay_yrly;
        private System.Windows.Forms.TextBox pymnts_dly;
        private System.Windows.Forms.TextBox pymnts_wkly;
        private System.Windows.Forms.TextBox pymnts_yrly;
        private System.Windows.Forms.TextBox pymnts_mthly;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox pay_mnthly;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox zinsProJahr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}

